require 'serverspec'
require 'net/ssh'

set :backend, :ssh
